op_version_set = 1
class Module(Module):
  __parameters__ = ["weight", "bias", ]
  training : bool
  weight : Tensor
  bias : Tensor
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_17.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self.bias
    input = torch._convolution(argument_1, self.weight, _0, [1, 1], [1, 1], [1, 1], False, [0, 0], 1, False, False, True)
    return input
