op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  preconv : __torch__.torch.nn.modules.module.___torch_mangle_2.Module
  conv1 : __torch__.torch.nn.modules.module.___torch_mangle_4.Module
  conv2 : __torch__.torch.nn.modules.module.___torch_mangle_6.Module
  conv3 : __torch__.torch.nn.modules.module.___torch_mangle_8.Module
  blk1 : __torch__.torch.nn.modules.module.___torch_mangle_16.Module
  blk2 : __torch__.torch.nn.modules.module.___torch_mangle_24.Module
  blk3 : __torch__.torch.nn.modules.module.___torch_mangle_34.Module
  blk4 : __torch__.torch.nn.modules.module.___torch_mangle_42.Module
  blk5 : __torch__.torch.nn.modules.module.___torch_mangle_52.Module
  blk6 : __torch__.torch.nn.modules.module.___torch_mangle_60.Module
  blk7 : __torch__.torch.nn.modules.module.___torch_mangle_70.Module
  blk8 : __torch__.torch.nn.modules.module.___torch_mangle_78.Module
  avgpool : __torch__.torch.nn.modules.module.___torch_mangle_79.Module
  fc : __torch__.torch.nn.modules.module.___torch_mangle_80.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_81.Module,
    input: Tensor) -> Tensor:
    _0 = self.fc
    _1 = self.avgpool
    _2 = self.blk8
    _3 = self.blk7
    _4 = self.conv3
    _5 = self.blk6
    _6 = self.blk5
    _7 = self.conv2
    _8 = self.blk4
    _9 = self.blk3
    _10 = self.conv1
    _11 = self.blk2
    _12 = (self.blk1).forward((self.preconv).forward(input, ), )
    _13 = (_11).forward(_12, )
    input0 = torch.add((_10).forward(_13, ), (_9).forward(_13, ), alpha=1)
    _14 = (_8).forward(input0, )
    input1 = torch.add((_7).forward(_14, ), (_6).forward(_14, ), alpha=1)
    _15 = (_5).forward(input1, )
    input2 = torch.add((_4).forward(_15, ), (_3).forward(_15, ), alpha=1)
    _16 = (_1).forward((_2).forward(input2, ), )
    _17 = ops.prim.NumToTensor(torch.size(_16, 0))
    input3 = torch.view(_16, [int(_17), -1])
    return (_0).forward(input3, )
