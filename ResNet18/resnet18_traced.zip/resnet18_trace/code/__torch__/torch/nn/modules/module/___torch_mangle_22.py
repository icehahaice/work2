op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.module.___torch_mangle_17.Module
  __annotations__["1"] = __torch__.torch.nn.modules.module.___torch_mangle_18.Module
  __annotations__["2"] = __torch__.torch.nn.modules.module.___torch_mangle_19.Module
  __annotations__["3"] = __torch__.torch.nn.modules.module.___torch_mangle_20.Module
  __annotations__["4"] = __torch__.torch.nn.modules.module.___torch_mangle_21.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_22.Module,
    argument_1: Tensor) -> Tensor:
    _0 = getattr(self, "1")
    _1 = (getattr(self, "0")).forward(argument_1, )
    _2 = getattr(self, "3")
    _3 = (getattr(self, "2")).forward((_0).forward(_1, ), )
    _4 = (getattr(self, "4")).forward((_2).forward(_3, ), )
    return _4
