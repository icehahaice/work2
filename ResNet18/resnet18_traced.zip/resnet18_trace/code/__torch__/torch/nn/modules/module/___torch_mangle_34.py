op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  blk : __torch__.torch.nn.modules.module.___torch_mangle_30.Module
  extra : __torch__.torch.nn.modules.module.___torch_mangle_33.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_34.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self.extra
    input = torch.add((self.blk).forward(argument_1, ), (_0).forward(argument_1, ), alpha=1)
    return torch.relu(input)
