op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.module.___torch_mangle_67.Module
  __annotations__["1"] = __torch__.torch.nn.modules.module.___torch_mangle_68.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_69.Module,
    argument_1: Tensor) -> Tensor:
    _0 = getattr(self, "1")
    _1 = (getattr(self, "0")).forward(argument_1, )
    return (_0).forward(_1, )
