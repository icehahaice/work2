op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  blk : __torch__.torch.nn.modules.module.___torch_mangle_58.Module
  extra : __torch__.torch.nn.modules.module.___torch_mangle_59.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_60.Module,
    input: Tensor) -> Tensor:
    _0 = self.extra
    _1 = (self.blk).forward(input, )
    _2 = (_0).forward()
    input0 = torch.add(_1, input, alpha=1)
    return torch.relu(input0)
