op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  blk : __torch__.torch.nn.modules.module.___torch_mangle_14.Module
  extra : __torch__.torch.nn.modules.module.___torch_mangle_15.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_16.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self.extra
    _1 = (self.blk).forward(argument_1, )
    _2 = (_0).forward()
    input = torch.add(_1, argument_1, alpha=1)
    return torch.relu(input)
